////////////////////////////Compiler/////////////////////////////////
/*
Author:Aniket Kumar
*/
#include <iostream>
#include <fstream>
#include "os.h"
#include "util.h"

// // Leaving a new line
//     cout << endl;
//     //Copying module file to base folder
//     system(string("mv "+filen+".csqm"+" "+bp).c_str());
//     system(string(string("mv process.cpp")+" "+bp).c_str());
//     // "g++ -std=c++17 process.cpp -o processRes && ./processRes"
//     //changing current directory to workspace directory
//     system((string("cd ")+bp).c_str());
//     // Calling g++ to compile source file
//     system((string("g++ -std=c++17 ")+filen+string(".cpp -o ")+filen).c_str());
//     //Calling executable created
//     system((string("./")+filen).c_str());
//     // system("rm process.cpp");

using namespace std;

// This method will read and create process.cpp
auto readSp(string sourcePath)
{
    ofstream writeC;
    ifstream readSource;
    readSource.open(sourcePath);
    writeC.open("process.cpp");
    string code, codeline;
    while (getline(readSource, codeline))
    {
        writeC << codeline << "\n";
    }
}

//Passname of file
auto writeName(string name){
    ofstream writeC;
    writeC.open("Name.nmp");
    writeC << name ; 
}

// Different Os participants

// For Linux________________________________________

auto linuxOsParticipant()
{
    // Info vars
    string sp, filen,bp;
    cout << "OsType:Linux" << endl;
    cout << "File Name:";
    cin >> filen;
    cout << "Source Path:";
    cin >> sp;
    cout << "Base Path:";
    cin >> bp;
    writeName(filen);
    // invoking readSp function to perform create process.cpp
    readSp(sp);
    // Calling python for syntax processing
    system("python3 csqCodeComp.py");
    
    //Moving cpp file created to th base directory
    system((string("mv process.cpp ")+bp).c_str());
    system((string("mv ")+filen+string(".csqm ")+bp).c_str());
    //New line
    cout<<"\n";
    /*******Running operation******************/
    //Changing current directory to base directory,compline with g++ and calling executable.
    system((string("cd ")+bp+string(" && ")+string("g++ process.cpp -o ")+filen+string(" && ")+string("./")+filen+string(" && rm ")+bp+"process.cpp").c_str());
    cout<<"\n";
}   
// __________________________________________________


//Participants for Windows

void windowsOsParticipant(){
    string fileloc,fn;
    cout<<"OsType:Windows"<<endl;
    cout<<"Name of file:";
    cin>>fn;
    cout<<"Source Path:";
    cin>>fileloc;
    writeName(fn);
    readSp(fileloc);
    system("python csqCodeCompW.py");
    cout << endl;
    // Calling g++ to run process.cpp
    system("g++ -o processRes process.cpp");
    system("processRes");
    cout<<endl;
}

int main(int argc, char const *argv[])
{
    // Name of Os
    string os = getOsname();

    // Determining Os
    if (os == "linux")
    {
        linuxOsParticipant();

    }

    else if (os=="windows"){
        windowsOsParticipant();
    }

    return 0;
}