#if !defined(DEPENDENCIES_H)
#define DEPENDENCIES_H

    //Neccessary Dependencies.
    #include <iostream>
    #include <typeinfo>
    #include <sstream>
    #include <fstream>
    #include <vector>
    #include <algorithm>
    #include <chrono>
    #include <ctime> 
    #include <filesystem>
    //Using statements.
    using std::chrono::duration_cast;
    using std::chrono::milliseconds;
    using std::chrono::seconds;
    using std::chrono::system_clock;
    using std::exception;
    // namespace fs___ = std::filesystem;
    #define _CsqVersion_ 2
#endif // DEPENDENCIES_H
