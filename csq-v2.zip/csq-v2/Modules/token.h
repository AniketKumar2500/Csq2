#if !defined(TOKEN_H)
#define TOKEN_H

    //Tokens funination
    #define var auto
    #define fun auto
    #define lam =[]
    #define lamda []

    #define when if(
    #define elif else if(
    #define If when
    #define so )
    #define then ){
    #define endh }

    #define forR(var_,from,till,steps) for (int var_=from;till;var_+=steps)
    #define forAr(var_,from,till,steps) for (int var_=from;till;var_-=steps)
    #define forE(var_,data) for (var &var_ : data)
    #define While while(

    #define __init__(classname) classname
    #define constructor(classname) classname
    #define destructor(classname) ~classname
    #define inherit :
    #define endclass };
    
    #define as(from,to) using to = from

    #define None NULL


    //Related to operator overloading
    #define __add__ fun operator +
    #define __gt__ fun operator >
    #define __lt__ fun operator <
    #define __equal__ fun operator ==
    #define __assign__ fun operator =
    #define __subt__ fun operator -
    #define __mul__ fun operator *
    #define __div__ fun operator /
    #define __pow__ fun operator ^
    #define __powassign__ fun operator ^=
    #define __brac__ fun operator []
    #define __cbrac__ fun operator ()
    #define __gteq__ fun operator >=
    #define __lteq__ fun operator <=
    #define __noteq__ fun operator !=
    #define __addassign__ fun operator +=
    #define __subtassign__ fun operator -=
    #define __mulassign__ fun operator *=
    #define __divassign__ fun operator /=
#endif // TOKEN_H
