#include "token.h"
#include "dependencies.h"
#define vect(type,var_) vector<type> var_
//type this->will allow us to find the type of a variable
#define Type(varr) typeid(varr).name()

#define call(funName) funName


///////////////advance OOPs////////////////
#define abstract(baseClass)
#define public public:
#define private private:
#define protected protected: