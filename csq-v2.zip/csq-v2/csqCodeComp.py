#########################Syntax Compiler##################################
'''
Author:Aniket Kumar
'''
import os
from unicodedata import name


# This function will process the syntax of the source file

def compileCode(code):
    code2='#include "'+os.getcwd()+'/Modules/builtins.csqm"\n'+code.replace("import", "#include").replace(".csq",'.csqm').replace("main:", "int main(int argc, char const *argv[]){").replace("endmain", "return 0;}").replace("this.","this->")
    return code2

# This function will read the process.cpp
def ReadProcess():
    # read process.cpp obj
    rp = open("process.cpp", 'r')
    # assigning code to code var
    code = compileCode(rp.read())
    return code

# This function will write process.cpp with new and compiled code
name_of_file = ''
def writeProcess(code):
    #Name read obj
    nrp = open("Name.nmp",'r')
    name_of_file = nrp.read()
    # Write obj
    wp = open(f"process.cpp", 'w')
    # Writing
    wp.write(code)
    #Module file
    wp2=open(name_of_file+".csqm",'w')
    wp2.write(code)




# Driver code

if __name__ == "__main__":
    # Invoking readprocess and writeprocess
    code = ReadProcess()
    # newCode = ''
    # for i in code.split("\n"):
    #     if '#include' not in i :
    #         newCode += i + " ;\n"
    #     else:
    #         newCode += i + "\n"
    writeProcess(code)
    
    pass
