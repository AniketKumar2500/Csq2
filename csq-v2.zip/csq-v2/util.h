#include <iostream>
using namespace std;
auto erasesubstr(string mainstr,const string & target){
    string rstr=mainstr;
    size_t pos = std::string::npos;
    while ((pos  = rstr.find(target) )!= std::string::npos){
        rstr.erase(pos, target.length());
    }
    return rstr;
}


string filterPath(string path,string fn){
    string ret="";
    for (int i = 0; i < path.size()-fn.size(); i++)
    {
        ret+=path[i];
    }
    return ret;
    
}