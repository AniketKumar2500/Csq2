import os

#All requirments
os.system("g++ csq-env.cpp -o csq-env")
os.system("g++ csqEX_gpp.cpp -o csqEX_gpp")