#include<iostream>
#include<vector>
using namespace std;


//Version directive
#define csq_version 2

namespace allapplic{
    void csqExecuter_gpp(){
        system("./csqEX_gpp");
    }
    void csqExecuter_clang(){
        system("./csqEX_Clpp");
    }
}

string allcommands(){
    vector<string> com={"[run-gpp:use if you have g++ compiler]","[run-cl:use if you have clang++ compiler]","[exit:exit the environment]","[install:This command let you install module with the help of urls","[version : displays the version of Csq]"};
    #if __linux__
        com.push_back("[clear:clearing the terminal]");
    #elif _WIN64 || _WIN32
        com.push_back("[cls:clearing the console]");
    #endif
    string s="";
    for(const auto & i:com){
        s+=i+",\n";
    }
    return s;
}

int main(int argc, char const *argv[]){
    
    while (true){
        string command="";
        cout<<"Csq-env >";
        cin>>command;

        //-----Checking-commands------
        if(command == "run-gpp"){
            allapplic::csqExecuter_gpp();
            cout<<"\n";
        }
        else if(command == "run-cl"){
            allapplic::csqExecuter_clang();
            cout<<"\n";
        }
        else if(command == "exit"){
            cout<<"bye!"<<"\n";
            break;
        }
        else if(command == "help"){
            cout<<allcommands()<<"\n";
        }

        else if(command == "version"){
            cout<<csq_version<<"\n";
        }

        #if __linux__
            else if(command == "clear"){
                system("clear");
                cout<<"\n";
            }

            else if(command == "install"){
                system("python3 getinstall.py");
            }
        #elif _WIN64 || _WIN32
            else if(command == "cls"){
            system("cls");
            cout<<"\n";
            }

            else if(command == "install"){
                system("python getinstall.py");
            }
        #endif
        else{
            cout<<"Not valid command:"<<command<<"\n";
        }

    }
    

    return 0;
}
