////////////////////////////Compiler/////////////////////////////////
/*
Author:Aniket Kumar
*/
#include <iostream>
#include <fstream>
#include "os.h"
#include "util.h"
using namespace std;

// This method will read and create process.cpp
auto readSp(string sourcePath)
{
    ofstream writeC;
    ifstream readSource;
    readSource.open(sourcePath);
    writeC.open("process.cpp");
    string code, codeline;
    while (getline(readSource, codeline))
    {
        writeC << codeline << "\n";
    }
}

//Passname of file
auto writeName(string name){
    ofstream writeC;
    writeC.open("Name.nmp");
    writeC << name ; 
}

// Different Os participants

// For Linux________________________________________

auto linuxOsParticipant()
{
    // Info vars
    string sp, filen,bp;
    cout << "OsType:Linux" << endl;
    cout << "File Name:";
    cin >> filen;
    cout << "Source Path:";
    cin >> sp;
    cout << "Base Path:";
    cin >> bp;
    writeName(filen);
    // invoking readSp function to perform create process.cpp
    readSp(sp);
    // Calling python for syntax processing
    system("python3 csqCodeComp.py");
    // Leaving a new line
    cout << endl;
    // Calling clang++ to run process.cpp
    system("clang++ process.cpp -o processRes && ./processRes");
    //Leaving a new line
    cout<<endl;
    //Copying module file to base folder
    system(string("mv "+filen+".csqm"+" "+bp).c_str());
}
// __________________________________________________


//Participants for Windows

void windowsOsParticipant(){
    string fileloc,fn;
    cout<<"OsType:Windows"<<endl;
    cout<<"Name of file:";
    cin>>fn;
    cout<<"Source Path:";
    cin>>fileloc;
    writeName(fn);
    readSp(fileloc);
    system("python csqCodeCompW.py");
    cout << endl;
    // Calling g++ to run process.cpp
    system("g++ -o processRes process.cpp");
    system("a.exe");
    cout<<endl;
}

int main(int argc, char const *argv[])
{
    // Name of Os
    string os = getOsname();

    // Determining Os
    if (os == "linux")
    {
        linuxOsParticipant();
    }

    else if (os=="windows"){
        windowsOsParticipant();
    }

    return 0;
}