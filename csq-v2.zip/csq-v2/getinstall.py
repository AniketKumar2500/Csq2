import requests,os
name = input("Name of modules:")
url = input("Url:")
code = requests.get(url)
codes = code.text
#Filehandling object
fo = open(os.getcwd()+"/Modules/"+name+".csqm",'w')

#Writing code
fo.write(codes)

